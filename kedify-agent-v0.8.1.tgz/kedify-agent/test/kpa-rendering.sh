#!/usr/bin/env bash

set -euo pipefail

chart_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
default_render="$(mktemp)"
enabled_render="$(mktemp)"
restricted_render="$(mktemp)"
multitenant_render="$(mktemp)"
dependency_render="$(mktemp)"
trap 'rm -f "${default_render}" "${enabled_render}" "${restricted_render}" "${multitenant_render}" "${dependency_render}"' EXIT

# A disabled KPA dependency must preserve the Agent's older Kubernetes support.
helm template test "${chart_dir}" --namespace keda --kube-version 1.23.0 \
  --values "${chart_dir}/test/test-values.yaml" >"${dependency_render}"
if grep -q '^# Source: kedify-agent/charts/kpa/' "${dependency_render}"; then
  echo "KPA resources must not be installed by default" >&2
  exit 1
fi

for multicluster_type in distributed dedicated; do
  helm template test "${chart_dir}" --namespace keda --kube-version 1.34.0 \
    --values "${chart_dir}/test/test-values.yaml" \
    --set global.features.multicluster.enabled=false \
    --set global.features.multicluster.type="${multicluster_type}" \
    --set kpa.enabled=true --set kpa.fullnameOverride=custom-kpa \
    --set kpa.controller.syncPeriod=7s >"${dependency_render}"
  for expected in 'name: custom-kpa' 'name: kedifypodautoscalers.autoscaling.kedify.io' '--sync-period=7s'; do
    if ! grep -qF -- "${expected}" "${dependency_render}"; then
      echo "Enabled KPA dependency is missing ${expected} with inactive ${multicluster_type} mode" >&2
      exit 1
    fi
  done
  if grep -q -- '--multicluster=true' "${dependency_render}"; then
    echo "Single-cluster KPA must not enable remote reconciliation" >&2
    exit 1
  fi
done

helm template test "${chart_dir}" \
  --namespace keda \
  --values "${chart_dir}/test/test-values.yaml" \
  --show-only templates/agent-deployment.yaml \
  --show-only templates/agent-rbac.yaml >"${default_render}"

helm template test "${chart_dir}" \
  --namespace keda \
  --values "${chart_dir}/test/test-values.yaml" \
  --set agent.features.kedifyPodAutoscalerEnabled=true \
  --show-only templates/agent-deployment.yaml \
  --show-only templates/agent-rbac.yaml >"${enabled_render}"

helm template test "${chart_dir}" \
  --namespace keda \
  --values "${chart_dir}/test/test-values.yaml" \
  --set global.features.kedifyPodAutoscalerEnabled=true \
  --set agent.rbac.readServices=false \
  --set agent.rbac.ingressAutoWire=false \
  --show-only templates/agent-deployment.yaml \
  --show-only templates/agent-rbac.yaml >"${restricted_render}"

helm template test "${chart_dir}" \
  --namespace keda \
  --values "${chart_dir}/test/test-values.yaml" \
  --set agent.features.multitenantKEDAEnabled=true \
  --show-only templates/agent-deployment.yaml \
  --show-only templates/agent-rbac.yaml >"${multitenant_render}"

if grep -q 'autoscaling.kedify.io' "${default_render}"; then
  echo "KPA RBAC must not be rendered by default" >&2
  exit 1
fi

if ! grep -A1 -F 'name: RBAC_READ_KPAS' "${default_render}" | grep -q 'value: "false"'; then
  echo "RBAC_READ_KPAS must be false by default" >&2
  exit 1
fi

if ! grep -A1 -F 'name: RBAC_READ_KPAS' "${enabled_render}" | grep -q 'value: "true"'; then
  echo "RBAC_READ_KPAS must be true when KPA support is enabled" >&2
  exit 1
fi

if ! grep -q 'autoscaling.kedify.io' "${enabled_render}" || \
   ! grep -q 'kedifypodautoscalers' "${enabled_render}"; then
  echo "KPA read RBAC must be rendered when KPA support is enabled" >&2
  exit 1
fi

if ! grep -A1 -F 'name: RBAC_READ_SERVICES' "${enabled_render}" | grep -q 'value: "true"' || \
   ! grep -q '^  - services$' "${enabled_render}"; then
  echo "Service discovery RBAC must remain available when KPA support is enabled" >&2
  exit 1
fi

if ! grep -A1 -F 'name: RBAC_READ_SERVICES' "${restricted_render}" | grep -q 'value: "false"'; then
  echo "KPA support must not advertise broad Service access when it only has list permission" >&2
  exit 1
fi

if ! grep -A1 -F 'name: RBAC_READ_KPAS' "${restricted_render}" | grep -q 'value: "true"'; then
  echo "KPA support must retain KPA read access when broad Service reads are disabled" >&2
  exit 1
fi

if ! grep -A1 -F 'name: RBAC_READ_CUSTOM_RESOURCE_DEFINITIONS' "${multitenant_render}" | grep -q 'value: "true"'; then
  echo "Multi-tenant installations must enable the KPA CRD metadata watch" >&2
  exit 1
fi

for resource in pods/log leases replicasets customresourcedefinitions; do
  if ! grep -q -- "- ${resource}" "${multitenant_render}"; then
    echo "Multi-tenant RBAC is missing ${resource}" >&2
    exit 1
  fi
done

crd_rule="$(grep -A7 '^  - customresourcedefinitions$' "${multitenant_render}")"
for verb in get list watch; do
  if ! grep -q -- "- ${verb}" <<<"${crd_rule}"; then
    echo "Multi-tenant CRD RBAC is missing ${verb}" >&2
    exit 1
  fi
done

restricted_service_rule="$(grep -A4 '^  - services$' "${restricted_render}")"
if ! grep -q '^  - list$' <<<"${restricted_service_rule}" || \
   grep -Eq '^  - (create|patch|update|watch)$' <<<"${restricted_service_rule}"; then
  echo "KPA-only Service discovery must receive list-only RBAC" >&2
  exit 1
fi
