{{- define "kpa.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "kpa.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else if contains (include "kpa.name" .) .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name (include "kpa.name" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{- define "kpa.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: {{ include "kpa.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: controller
app.kubernetes.io/part-of: kedify-pod-autoscaler
{{- end }}

{{- define "kpa.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kpa.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "kpa.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "kpa.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- required "serviceAccount.name is required when serviceAccount.create=false" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "kpa.image" -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag -}}
{{- if .Values.image.hardened -}}
{{ printf "%s:%s-hardened" .Values.image.repository $tag }}
{{- else -}}
{{ printf "%s:%s" .Values.image.repository $tag }}
{{- end -}}
{{- end }}

{{- define "kpa.leaderElectionID" -}}
{{- default (printf "%s-leader" (include "kpa.fullname" .)) .Values.controller.leaderElectionID -}}
{{- end }}

{{/* Return true for explicit standalone mode or Agent dedicated mode. */}}
{{- define "kpa.multiclusterEnabled" -}}
{{- $global := default (dict) .Values.global -}}
{{- $features := default (dict) (index $global "features") -}}
{{- $multicluster := default (dict) (index $features "multicluster") -}}
{{- $dedicated := and (hasKey $multicluster "type") (index $multicluster "enabled") (eq (default "distributed" (index $multicluster "type")) "dedicated") -}}
{{- if or .Values.multicluster.enabled $dedicated -}}true{{- else -}}false{{- end -}}
{{- end }}

{{/* Use the parent release namespace for the bundled KEDA endpoint. */}}
{{- define "kpa.kedaMetricsAddress" -}}
{{- $global := default (dict) .Values.global -}}
{{- $features := default (dict) (index $global "features") -}}
{{- $multicluster := default (dict) (index $features "multicluster") -}}
{{- if and (hasKey $multicluster "type") (eq .Values.keda.metricsAddress "keda-operator.keda.svc:9666") -}}
{{- printf "keda-operator.%s.svc:9666" .Release.Namespace -}}
{{- else -}}
{{- .Values.keda.metricsAddress -}}
{{- end -}}
{{- end }}

{{- define "kpa.kedaMetricsAuthority" -}}
{{- $global := default (dict) .Values.global -}}
{{- $features := default (dict) (index $global "features") -}}
{{- $multicluster := default (dict) (index $features "multicluster") -}}
{{- if and (hasKey $multicluster "type") (eq .Values.keda.metricsAuthority "keda-operator.keda.svc") -}}
{{- printf "keda-operator.%s.svc" .Release.Namespace -}}
{{- else -}}
{{- .Values.keda.metricsAuthority -}}
{{- end -}}
{{- end }}
