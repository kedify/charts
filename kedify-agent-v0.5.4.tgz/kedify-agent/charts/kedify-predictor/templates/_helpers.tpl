{{/*
Expand the name of the chart.
*/}}
{{- define "kedify-predictor.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "kedify-predictor.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kedify-predictor.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kedify-predictor.labels" -}}
helm.sh/chart: {{ include "kedify-predictor.chart" . }}
{{ include "kedify-predictor.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kedify-predictor.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kedify-predictor.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app: kedify-predictor
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "kedify-predictor.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "kedify-predictor.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Env vars for database
*/}}
{{- define "kedify-predictor.dbEnvVars" -}}
{{- with .Values.db }}
{{- if eq .type "postgres" }}
# DB
- name: DB_TYPE
  value: "postgres"
{{- if .useSecretAndConfigmap }}
{{- if .host }}
- name: DB_HOST
  valueFrom:
    configMapKeyRef:
      name: {{ include "kedify-predictor.fullname" $ }}-env
      key: DB_HOST
{{- end }}
{{- if .port }}
- name: DB_PORT
  valueFrom:
    configMapKeyRef:
      name: {{ include "kedify-predictor.fullname" $ }}-env
      key: DB_PORT
{{- end }}
{{- if .user }}
- name: DB_USER
  valueFrom:
    configMapKeyRef:
      name: {{ include "kedify-predictor.fullname" $ }}-env
      key: DB_USER
{{- end }}
{{- if .password }}
- name: DB_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ include "kedify-predictor.fullname" $ }}-env
      key: {{ .existingSecretPasswordKey | default "DB_PASSWORD" }}
{{- end }}
{{- if .name }}
- name: DB_NAME
  valueFrom:
    configMapKeyRef:
      name: {{ include "kedify-predictor.fullname" $ }}-env
      key: DB_NAME
{{- end }}
{{- else }}
{{- with .host }}
- name: DB_HOST
  value: {{ . | quote }}
{{- end }}
{{- with .port }}
- name: DB_PORT
  value: {{ . | quote }}
{{- end }}
{{- with .user }}
- name: DB_USER
  value: {{ . | quote }}
{{- end }}
{{- if .password }}
- name: DB_PASSWORD
  value: {{ .password | quote }}
{{- else if .existingSecret }}
- name: DB_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .existingSecret }}
      key: {{ .existingSecretPasswordKey | default "DB_PASSWORD" }}
{{- end }}
{{- with .name }}
- name: DB_NAME
  value: {{ . | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
CRD installation labels
*/}}
{{- define "crdInstall" -}}
{{- printf "%s-%s" ( include "kedify-predictor.name" . ) "crd-install" | replace "+" "_" | trimSuffix "-" -}}
{{- end -}}

{{- define "crdPostInstallAnnotations" -}}
"helm.sh/hook": "post-install,post-upgrade"
"helm.sh/hook-delete-policy": "before-hook-creation,hook-succeeded,hook-failed"
{{- end -}}

{{/*
true if training jobs should be scheduled on the same node as predictor deployment
*/}}
{{- define "jobsMustShareNode" -}}
{{- printf "%s" (and (eq .Values.db.type "sqlite") (not (has "ReadWriteMany" .Values.settings.storage.accessModes)) | ternary "true" "false") -}}
{{- end -}}
