{{- define "prophet.container" -}}
- name: keda-prophet
  image: "{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}"
  args:
  - --server
  imagePullPolicy: {{ .Values.image.pullPolicy }}
  {{- if .Values.kedaPredictionController.enabled }}
  restartPolicy: Always
  {{- end }}
  ports:
    - name: http
      containerPort: {{ .Values.service.port }}
      protocol: TCP
  env:
    - name: DB_FILE
      value: {{ .Values.settings.storage.dbFile }}
    - name: MODELS_PATH
      value: {{ .Values.settings.storage.modelsPath }}
    {{- include "kedify-predictor.dbEnvVars" . | nindent 4 }}
  {{- with .Values.livenessProbe }}
  livenessProbe:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.readinessProbe }}
  readinessProbe:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.resources }}
  resources:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.securityContext }}
  securityContext:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- if or (not .Values.kedaPredictionController.noSharedVolumes) .Values.extraVolumeMounts }}
  volumeMounts:
  {{- if not .Values.kedaPredictionController.noSharedVolumes }}
  {{- with .Values.volumeMounts }}
  {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- end }}
  {{- with .Values.extraVolumeMounts }}
  {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- end }}
{{- end }}
