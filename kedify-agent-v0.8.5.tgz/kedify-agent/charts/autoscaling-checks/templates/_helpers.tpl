{{- define "autoscaling-checks.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "autoscaling-checks.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := include "autoscaling-checks.name" . -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "autoscaling-checks.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "autoscaling-checks.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "autoscaling-checks.labels" -}}
app.kubernetes.io/name: autoscaling-checks
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: autoscaling-checks
{{- end -}}

{{- define "autoscaling-checks.roleLabels" -}}
{{ include "autoscaling-checks.labels" .root }}
autoscaling-checks.kedify.io/check: {{ .check }}
autoscaling-checks.kedify.io/role: {{ .role }}
{{- end -}}

{{- define "autoscaling-checks.workloadName" -}}
{{- printf "%s-check-%s-%s" (include "autoscaling-checks.fullname" .root) .check .role | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "autoscaling-checks.runnerName" -}}
{{- include "autoscaling-checks.workloadName" (dict "root" .root "check" .check "role" "runner") -}}
{{- end -}}

{{- define "autoscaling-checks.targetName" -}}
{{- include "autoscaling-checks.workloadName" (dict "root" .root "check" .check "role" "target") -}}
{{- end -}}

{{- define "autoscaling-checks.scaledObjectName" -}}
{{- include "autoscaling-checks.workloadName" (dict "root" .root "check" .check "role" "scaledobject") -}}
{{- end -}}

{{- define "autoscaling-checks.hpaName" -}}
{{- printf "%s-check-%s-hpa" (include "autoscaling-checks.fullname" .root) .check | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "autoscaling-checks.scaledObjectAnnotations" -}}
{{- $class := lower .Values.autoscaler.class -}}
{{- if not (has $class (list "auto" "hpa" "kpa")) -}}
{{- fail "autoscaler.class must be auto, hpa, or kpa" -}}
{{- end -}}
{{- if ne $class "auto" -}}
autoscaling.kedify.io/class: {{ $class | quote }}
{{- if and (eq $class "kpa") (ne .Values.autoscaler.syncPeriodSeconds nil) }}
{{- $period := int .Values.autoscaler.syncPeriodSeconds -}}
{{- if or (lt $period 1) (gt $period 3600) -}}
{{- fail "autoscaler.syncPeriodSeconds must be between 1 and 3600" -}}
{{- end }}
autoscaling.kedify.io/sync-period-seconds: {{ $period | quote }}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "autoscaling-checks.runnerEnv" -}}
{{- $targetName := include "autoscaling-checks.targetName" . -}}
{{- $scaledObjectName := include "autoscaling-checks.scaledObjectName" . -}}
{{- $targetURL := default (printf "http://%s:8080" $targetName) .targetURL -}}
{{- $runtimeManaged := (default dict .root.Values.scaledObjects).runtimeManaged | default false -}}
{{- with lookup "apps/v1" "Deployment" .root.Release.Namespace (include "autoscaling-checks.runnerName" .) -}}
  {{- $installedRuntime := false -}}
  {{- range .spec.template.spec.containers -}}
    {{- if eq .name "runner" -}}
      {{- range .env -}}
        {{- if eq .name "SCALED_OBJECT_MANIFEST" -}}
          {{- $installedRuntime = true -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
  {{- if ne $runtimeManaged $installedRuntime -}}
    {{- fail "keep scaledObjects.runtimeManaged unchanged for existing Autoscaling Checks releases" -}}
  {{- end -}}
{{- end -}}
- name: POD_NAMESPACE
  valueFrom:
    fieldRef:
      fieldPath: metadata.namespace
- name: CHECK_INTERVAL
  value: {{ .root.Values.common.checkInterval | quote }}
- name: CHECK_TIMEOUT
  value: {{ .root.Values.common.checkTimeout | quote }}
- name: METRIC_TIMEOUT
  value: {{ .root.Values.common.metricTimeout | quote }}
- name: SCALE_UP_TIMEOUT
  value: {{ .root.Values.common.scaleUpTimeout | quote }}
- name: SCALE_DOWN_TIMEOUT
  value: {{ .root.Values.common.scaleDownTimeout | quote }}
{{- if $runtimeManaged }}
- name: SCALED_OBJECT_MANIFEST
  value: {{ include (printf "autoscaling-checks.scaledObject.%s" .check) .root | b64enc | quote }}
{{- end }}
- name: SCALED_OBJECT_NAME
  value: {{ $scaledObjectName | quote }}
- name: HPA_NAME
  value: {{ include "autoscaling-checks.hpaName" . | quote }}
- name: AUTOSCALER_CLASS
  value: {{ lower .root.Values.autoscaler.class | quote }}
- name: TARGET_DEPLOYMENT
  value: {{ $targetName | quote }}
- name: TARGET_URL
  value: {{ $targetURL | quote }}
{{- end -}}

{{- define "autoscaling-checks.enabledChecks" -}}
{{- $checks := list -}}
{{- range $check := list "http" "prometheus" "otel" "cpu" "memory" -}}
  {{- if (index $.Values $check).enabled -}}
    {{- $checks = append $checks $check -}}
  {{- end -}}
{{- end -}}
{{- $checks | toJson -}}
{{- end -}}
