{{- define "autoscaling-checks.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "autoscaling-checks.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := include "autoscaling-checks.name" . -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "autoscaling-checks.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "autoscaling-checks.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "autoscaling-checks.labels" -}}
app.kubernetes.io/name: autoscaling-checks
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: autoscaling-checks
{{- end -}}

{{- define "autoscaling-checks.roleLabels" -}}
{{ include "autoscaling-checks.labels" .root }}
autoscaling-checks.kedify.io/check: {{ .check }}
autoscaling-checks.kedify.io/role: {{ .role }}
{{- end -}}

{{- define "autoscaling-checks.workloadName" -}}
{{- printf "%s-check-%s-%s" (include "autoscaling-checks.fullname" .root) .check .role | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "autoscaling-checks.runnerName" -}}
{{- include "autoscaling-checks.workloadName" (dict "root" .root "check" .check "role" "runner") -}}
{{- end -}}

{{- define "autoscaling-checks.targetName" -}}
{{- include "autoscaling-checks.workloadName" (dict "root" .root "check" .check "role" "target") -}}
{{- end -}}

{{- define "autoscaling-checks.scaledObjectName" -}}
{{- include "autoscaling-checks.workloadName" (dict "root" .root "check" .check "role" "scaledobject") -}}
{{- end -}}

{{- define "autoscaling-checks.hpaName" -}}
{{- printf "%s-check-%s-hpa" (include "autoscaling-checks.fullname" .root) .check | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "autoscaling-checks.runnerEnv" -}}
{{- $targetName := include "autoscaling-checks.targetName" . -}}
{{- $scaledObjectName := include "autoscaling-checks.scaledObjectName" . -}}
{{- $targetURL := default (printf "http://%s:8080" $targetName) .targetURL -}}
- name: POD_NAMESPACE
  valueFrom:
    fieldRef:
      fieldPath: metadata.namespace
- name: CHECK_INTERVAL
  value: {{ .root.Values.common.checkInterval | quote }}
- name: CHECK_TIMEOUT
  value: {{ .root.Values.common.checkTimeout | quote }}
- name: METRIC_TIMEOUT
  value: {{ .root.Values.common.metricTimeout | quote }}
- name: SCALE_UP_TIMEOUT
  value: {{ .root.Values.common.scaleUpTimeout | quote }}
- name: SCALE_DOWN_TIMEOUT
  value: {{ .root.Values.common.scaleDownTimeout | quote }}
- name: SCALED_OBJECT_NAME
  value: {{ $scaledObjectName | quote }}
- name: HPA_NAME
  value: {{ include "autoscaling-checks.hpaName" . | quote }}
- name: TARGET_DEPLOYMENT
  value: {{ $targetName | quote }}
- name: TARGET_URL
  value: {{ $targetURL | quote }}
{{- end -}}
